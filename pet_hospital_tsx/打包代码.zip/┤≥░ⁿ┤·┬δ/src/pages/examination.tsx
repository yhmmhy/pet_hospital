
import TestLayout from '../components/Examination/TestLayout'
function Examination() {
  return (
    <div>
      <TestLayout />
    </div>

  )
}

export default Examination
